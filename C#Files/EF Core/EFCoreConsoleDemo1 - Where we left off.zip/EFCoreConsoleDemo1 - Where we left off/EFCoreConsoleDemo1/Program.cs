﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace EFCoreConsoleDemo1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using var context = new AppDBContext();

            //AddManyProducts(context);
            //AddManyVendors(context);

            GetAllProducts(context);

           //GetAllVendors(context);

            Console.WriteLine();
            Console.WriteLine("Done. Press any key to exit.");
            Console.ReadLine();


        }

        private static void GetAllVendors(AppDBContext context)
        {
            var allVendors = context.Vendors.ToList();

            foreach (var vendor in allVendors)
            {
                Console.WriteLine($"{vendor.Name} - {vendor.City},  {vendor.State}");
            }
        }

        private static void GetAllProducts(AppDBContext context)
        {
            var allProducts = context.Products.ToList();

            context.Vendors.ToList();

            foreach (var product in allProducts)
            {
                Console.WriteLine($"{product.Name} - {product.Price} Vendor: {product.Vendor?.Name}");
            }
        }

        private static void AddManyVendors(AppDBContext context)
        {
            var vendor = new Vendor[]
            {
                new Vendor { Name = "TQL", City = "Cincinnati", State = "OH" },
                new Vendor { Name = "Gadget World", City = "New York", State = "NY" },
                new Vendor { Name = "Micro Center", City = "Columbus", State = "OH" },
                new Vendor { Name = "Best Buy", City = "Los Angeles", State = "CA" }
            };

            context.Vendors.AddRange(vendor);
            context.SaveChanges();

            Console.WriteLine($"{vendor.Count()} vendors added to the database.");
        }

        private static void AddManyProducts(AppDBContext context)
        {
            var product = new Product[]
            {
                new Product { Name = "Chair", Price = 127.95M, VendorId = 1 },
                new Product { Name = "Desk", Price = 99.99M, VendorId = 1 },
                new Product { Name = "Lamp", Price = 50.00M, VendorId = 3 },
                new Product { Name = "Printer", Price = 35.50M, VendorId = 4 },
                new Product { Name = "Shredder", Price = 35.80M, VendorId = 4 }
            };

            context.Products.AddRange(product);
            context.SaveChanges();

            Console.WriteLine($"{product.Count()} products added to the database.");

            //var products = context.Products.ToList();

            //foreach (var item in products)
            //{
            //    Console.WriteLine($"{item.Id}: {item.Name} - {item.Price:C}");
            //}
        }
    }
}
