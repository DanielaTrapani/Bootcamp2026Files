﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCoreConsoleDemo1
{
    internal class Vendor
    {
        public int Id { get; set; }

        [Column(TypeName = "varchar(30)")]
        public string Name { get; set; } = string.Empty;

        [Column(TypeName = "varchar(30)")]
        public string City { get; set; } = string.Empty;

        [Column(TypeName = "varchar(2)")]
        public string State { get; set; } = string.Empty;
    }
}
