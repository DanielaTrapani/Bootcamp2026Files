﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCoreConsoleDemo1
{
    internal class Product
    {
        public int Id { get; set; }

        [Column(TypeName = "varchar(30)")]
        public string Name { get; set; } = string.Empty;

        [Column(TypeName = "decimal(11,2)")]
        public decimal Price { get; set; }

        public int VendorId { get; set; }  // Foreign key property

        public Vendor? Vendor { get; set; }  // Navigation property



    }
}
